<?php
// Start the session
session_start();

// Retrieve session variables
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;

// Database connection
$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
$result = mysqli_query($conn, $sql);

// Redirect to login page if not logged in
if ($result && ($userNAME != null && $userPASSWORD != null)) {
    $num_rows = mysqli_num_rows($result);
    if ($num_rows > 0) {
        $user = mysqli_fetch_assoc($result);
        $first = $user['user_firstname'];
        $last = $user['user_lastname'];
        $name = $first . " " . $last;
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
    }
} else {
    header('Location: opportUnity_login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - OpportUnity</title>
    <link rel="stylesheet" href="opportUnity_dashboard_jobseeker.css">
    <link rel="icon" type="image/png" href="faviconlogo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spectral&display=swap" rel="stylesheet">
    <style>
        *{
            padding:0px;
            margin:0px;
        }
        header{
            background-color:#0481fe;
            width:100%;
            height: 60px;
            display:flex;
            justify-content:space-between;
            font-size:30px;
        }
        span{
            display:flex;
            justify-content:center;
            align-items:center;
            color:white;
            width: 250px;
        }
        .nav-bar{
            display:flex;
            justify-content:center;
            align-items:center;
            color:#ffffff;
            font-size: 20px;
            width: 250px;
        }
        .prof{
            display:flex;
            align-items:center;
            width: 80px;
        }
        nav{
            display:flex;
            justify-content:center;
            align-items:center;
        }
        ul{
            display:flex;
            justify-content:space-evenly;
            align-items:center;
            font-size: 16px;
            width: 300px;
        }
        li{
            color:#ffffff;
            list-style-type:none;
            cursor:pointer;
        }
        a{
            text-decoration:none;
            color:#ffffff;
        }
        .cont{
            height:100vh;
            display:flex;
            flex-direction:column;
        }
        #dataSec{
            height:100%;
            width: 100%;
        }
        .cntx{
            height:250px;
            width: 400px;
            border-radius: 10px;
            background-color:#029b28;
            margin: 5px;
            color:white;
            display: flex;
            flex-direction:column;
            justify-content:space-evenly;
            padding-left: 10px;
        }
        img{
            height: 40px;;
            width: 40px;
            border-radius:50%;
        }
        .btn{
            width: 80px;
            height: 20px;
            background-color:#2b972f;
            color:white;
            border-radius:5px;
        }
        #job{
            display:flex;
            width: 100%;
            border:1px solid black;
            justify-content:center;
        }
        #applicantslist{
            display:flex;
            width: 100%;
            border:1px solid black;
            justify-content:center;
        }
        .contnr{
            display:flex;
            width: 100%;
            justify-content:space-evenly;
            flex-direction:row;
        }
    </style>
</head>
<body>
    <!-- Form to send the name of the job seeker into a database and the company name he applies to -->
    <form action="apply.php" id="myForm" method="POST">
        <input type="hidden" id="jobpos" name="jobpos">
        <input type="hidden" id="compName" name="compName">
        <input type="hidden" id="fname" name="fname">
        <input type="hidden" id="lname" name="lname">
        <input type="hidden" id="job_id" name="job_id">
        <input type="hidden" id="user_id" name="user_id">
    </form>
    <!-- Nav bar -->
    <nav class="navbar">
        <div class="navbar-left">
        <img onclick="logout()" src="logo.png" alt="OpportUnity Logo" class="navbar-logo">
        <div onclick="logout()" class="logo">OpportUnity</div>
            <ul class="nav-links">
                <li><a href="opportUnity.html">Landing Page</a></li>
                <li><a href="#">Terms & Condition</a></li>
            </ul>
        </div>
        <div class="navbar-right">
            <div id="userMenu" class="user-menu">
                <span id="userName">Welcome, <?php echo htmlspecialchars($name); ?>!</span>
                <div id="dropdown" class="dropdown-content">
                    <a href="profile.html">View Profile</a>
                    <a id="gotoLogout">Logout</a>
                </div>
            </div>
            <img src="<?=$pic?>" alt="default_profile.jpg" width="100px" height="100px">
        </div>
    </nav>

    <div>
        <h1>OpportUnity</h1>
        <div id="container">
            <h2>Dashboard</h2>
            <a href="opportUnity_joblist_jobseeker.php"><button>Applied Jobs</button></a>
            <h2>Available Jobs</h2>
            <div id="job-list-container">
            </div>
        </div>
    </div>

    <script>
    var jobid;
    var companyname;
    var jobname;
    var jobdesc;
    var userid;

    setInterval(xmlhr, 1000);

    function xmlhr() {
        // AJAX
        var xml = new XMLHttpRequest();
        var method = "GET";
        var url = "cntx_opportUnity_dashboard_jobseeker.php";
        var asynchronous = true;

        xml.open(method, url, asynchronous);
        xml.send();
        xml.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var data = JSON.parse(this.responseText);
                var htmldata = document.getElementById('job-list-container');
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    //retreive the data using ajax from sql
                    jobid = data[i].jobid;
                    companyname = data[i].companyname;
                    jobname = data[i].jobname;
                    jobdesc = data[i].jobdesc;
                    job_location = data[i].job_location;
                    salary = data[i].salary;
                    requirements = data[i].requirements;
                    qualities = data[i].qualities;
                    expectation = data[i].expectation;
                    userid = data[i].userid;
                    datetime_job_created = data[i].datetime_job_created;
                    //var joblogo = data[i].joblogo;

                    html += "<div class='cntx'><div class='cnpc'>";
                    //html += "<img src='" + joblogo + "' width='100px' height='100px'/>";
                    html += "</div>";
                    html += "<h1 class='jobposition'> Job position: " + jobname + "</h1>";
                    html += "<h2> Salary $" + salary + "</h2>";
                    html += "<h3 class='cname'> Company: " + companyname + "</h3>";
                    html += "<h5> Job Description: " + jobdesc + "</h5>";
                    html += "<h5> Job Requirements: " + requirements + "</h5>";
                    html += "<h5> Job Qualities: " + qualities + "</h5>";
                    html += "<h5> Job Expectations: " + expectation + "</h5>";
                    html += "<h5 class='jid'> Job ID: " + jobid + "</h5>";
                    html += "<input type='hidden' class='employerid' value='" + userid + "'>";
                    html += "<button onclick='applyy(this)'>APPLY</button>";
                    html += "</h1></div>";
                }
                htmldata.innerHTML = html;
            }
        }
    }

    function logout() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'logout.php', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                alert(xhr.responseText);
                window.location.href = 'opportUnity_login.php';
            }
        };
        xhr.send();
    }

    function applyy(button) {
        // JSON from PHP
        var firstname = "<?php echo htmlspecialchars($first); ?>";
        var lastname = "<?php echo htmlspecialchars($last); ?>";

        // Traverse the DOM to find the company name within the same div
        var datatype_compname = button.closest('.cntx').querySelector('.cname').textContent.replace(' Company: ', '');
        var datatype_job_id = button.closest('.cntx').querySelector('.jid').textContent.replace(' Job ID: ', '');
        var datatype_jobposition = button.closest('.cntx').querySelector('.jobposition').textContent.replace(' Job position: ', '');
        var datatype_userid = button.closest('.cntx').querySelector('.employerid').value;
        document.getElementById("compName").value = datatype_compname;
        document.getElementById("fname").value = firstname;
        document.getElementById("lname").value = lastname;
        document.getElementById("job_id").value = datatype_job_id;
        document.getElementById("jobpos").value = datatype_jobposition;
        document.getElementById("user_id").value = datatype_userid;
        document.getElementById('myForm').submit();
    }
    </script>
</body>
</html>
