<?php
//global variable
session_start();
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;
$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT * FROM user WHERE user_username=? AND user_password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userNAME, $userPASSWORD);
$stmt->execute();
$result = $stmt->get_result();

// If the main page cannot be accessed without logging in
// This is responsible for redirecting the user into the login page
if ($result && ($userNAME != null && $userPASSWORD != null)) {
    $num_rows = mysqli_num_rows($result);
    if ($num_rows > 0) {
        $user = mysqli_fetch_assoc($result);
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
    }
} else {
    session_abort();
    include 'opportUnity_login.php';
    exit();
}
$first = $_SESSION['firstname'];
$last = $_SESSION['lastname'];
$name = $first . " " . $last;
$pic = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            padding:0px;
            margin:0px;
        }
        header{
            background-color:#0481fe;
            width:100%;
            height: 60px;
            display:flex;
            justify-content:space-between;
            font-size:30px;
        }
        span{
            display:flex;
            justify-content:center;
            align-items:center;
            color:#ffb900;
            width: 250px;
        }
        .nav-bar{
            display:flex;
            justify-content:center;
            align-items:center;
            color:#ffffff;
            font-size: 20px;
            width: 250px;
        }
        .prof{
            display:flex;
            align-items:center;
            width: 80px;
        }
        nav{
            display:flex;
            justify-content:center;
            align-items:center;
        }
        ul{
            display:flex;
            justify-content:space-evenly;
            align-items:center;
            font-size: 16px;
            width: 300px;
        }
        li{
            color:#ffffff;
            list-style-type:none;
            cursor:pointer;
        }
        a{
            text-decoration:none;
            color:#ffffff;
        }
        .cont{
            height:100vh;
            display:flex;
            flex-direction:column;
        }
        #dataSec{
            height:100%;
            width: 100%;
        }
        .cntx{
            height:250px;
            width: 400px;
            border-radius: 10px;
            background-color:#029b28;
            margin: 5px;
            color:white;
            display: flex;
            flex-direction:column;
            justify-content:space-evenly;
            padding-left: 10px;
        }
        img{
            height: 40px;;
            width: 40px;
            border-radius:50%;
        }
        .btn{
            width: 80px;
            height: 20px;
            background-color:transparent;
            border:2px solid white;
            color:white;
            border-radius:5px;
        }
        #job{
            display:flex;
            width: 100%;
            border:1px solid black;
            justify-content:center;
        }
        #applicantslist{
            display:flex;
            width: 98%;
            border:1px solid black;
            justify-content:center;
        }
        .contnr{
            display:flex;
            width: 100%;
            justify-content:space-evenly;
            flex-direction:row;
            background-color:#303030;
        }
    </style>
</head>
<body>
    <a href="opportUnity_dashboard_jobseeker.php"><button style="font-size:20px; display:flex; justify-content:center; align-items:center;">←</button></a>
    <h1>All Applied jobs</h1>
    <div id="job-list-container"></div>

<script>
    var uid = <?php echo $userID; ?>;
    var jobid;
    var companyname;
    var jobname;
    var jobdesc;
    var userid;

    setInterval(getListOfJob, 1000);

    function getListOfJob() {
        // AJAX
        var xml = new XMLHttpRequest();
        var method = "GET";
        var url = "joblist_opportUnity_dashboard_jobseeker.php?user_id="+uid;
        var asynchronous = true;

        xml.open(method, url, asynchronous);
        xml.send();
        xml.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var data = JSON.parse(this.responseText);
                var htmldata = document.getElementById('job-list-container');
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    //retreive the data using ajax from sql
                    jobid = data[i].jobid;
                companyname = data[i].companyname;
                jobname = data[i].jobname;
                jobdesc = data[i].jobdesc;
                job_location = data[i].job_location;
                salary = data[i].salary;
                requirements = data[i].requirements;
                qualities = data[i].qualities;
                expectation = data[i].expectation;
                userid = data[i].userid;
                datetime_job_created = data[i].datetime_job_created;
                jobstatus = data[i].job_status;
                employer_userid = data[i].userid;
                //var joblogo = data[i].joblogo;

                html += "<div class='cntx'><div class='cnpc'>";
                //html += "<img src='" + joblogo + "' width='100px' height='100px'/>";
                html += "</div>";
                html += "<h1> Job position: " + jobname + "</h1>";
                html += "<h2> Salary $" + salary + "</h2>";
                html += "<h3 class='cname'> Company: " + companyname + "</h3>";
                // html += "<h5> Job Description: " + jobdesc + "</h5>";
                // html += "<h5> Job Requirements: " + requirements + "</h5>";
                // html += "<h5> Job Qualities: " + qualities + "</h5>";
                // html += "<h5> Job Expectations: " + expectation + "</h5>";
                html += "<div style='width:350px; display:flex; justify-content:space-between;'><h5> Job ID: " + jobid + "</h5> <h5 style='width:90px;'> Status: " + jobstatus + "</h5></div>";

                // View Button Form
                html += '<div style="display:flex; justify-content:space-around; width:100%;">';
                html += '<form action="view_detail.php" method="POST">'
                html += '<input type="hidden" name="id" value="'+jobid+'">';
                html += '<input type="hidden" name="jobname" value="'+jobname+'">';
                html += '<input type="hidden" name="salary" value="'+salary+'">';
                html += '<input type="hidden" name="compname" value="'+companyname+'">';
                html += '<input type="hidden" name="jobdesc" value="'+jobdesc+'">';
                html += '<input type="hidden" name="req" value="'+requirements+'">';
                html += '<input type="hidden" name="qual" value="'+qualities+'">';
                html += '<input type="hidden" name="expect" value="'+expectation+'">';
                html += '<input type="hidden" name="different_user_userid" value="'+employer_userid+'">';
                html += '<button class="btn" type="submit">View details</button></form>';
                console.log(employer_userid);
                console.log(jobname);
                

                var msg = 'Are you sure you want to cancel this job?';
                // Delete Button Form
                html += '<form action="cancel.php" method="POST" onsubmit="return confirm(\'' + msg + '\')">';
                html += '<input type="hidden" name="id" value="'+jobid+'">';
                html += '<button class="btn" type="submit">Cancel</button></form>';
                
                html += "</div></div>";
            }
            html += "</div>";
            htmldata.innerHTML = html;
            }
        }
    }
    </script>
</body>
</html>