<?php
// Start the session
session_start();

    // Global variables
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';
    // purpose nito is kahit na ivisit ng user yung ibang user is mananatili padin yung notif nya
    if ($result && ($userNAME != null && $userPASSWORD != null)) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) 
        {
            $user = mysqli_fetch_assoc($result);
            $first = $user['user_firstname'];
            $last = $user['user_lastname'];
            $name = $first . " " . $last;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            $_SESSION['usertype'] = $role;
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);
            $user_notification = $user['user_notification'];
            $user_ID = $user['user_ID'];
        }
    }

// ito ay kapag yung employer nagview ng profile ng user

// kapag niclick ng user yung ibang user profile, ito yung gagana
// kapag nag flase tong if statement na to, ibigsabihin niclick ng user sarili nyang profile
if (isset($_POST['different_user_type']) && isset($_POST['different_user_userid']) && $_POST['different_user_type'] == "employee") 
{ 
    // ito ay para ihide yung edit button kapag nagview ng profile ng iba yung user
    $edit = false;

    // it ay para makita sa navigationbar yung profile ng user(hindi user na ivivisit)
    // Retrieve session variables
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $userID = $_SESSION['id'] ?? null;

    // Database connection
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';

    // Redirect to login page if not logged in
    if ($result && ($userNAME != null && $userPASSWORD != null)) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $first = $user['user_firstname'];
            $last = $user['user_lastname'];
            $name = $first . " " . $last;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);
        }
    }

    //eto naman yung para sa user na vivisit
    $different_user_type = $_POST['different_user_type']; 
    $different_user_userid = $_POST['different_user_userid'];

    // $different_user_userid at $different_user_role ay parehas lang

    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_ID='$different_user_userid' AND user_type='$different_user_type'";
    $result = mysqli_query($conn, $sql);

    $different_user_pic_identifier = '';
    
    if ($result) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $different_user_user = mysqli_fetch_assoc($result);
            $different_user_first = $user['user_firstname'];
            $different_user_last = $user['user_lastname'];
            $different_user_name = $different_user_first . " " . $different_user_last;
            $different_user_pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $different_user_role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $different_user_pic_identifier = base64_encode($user['profile_photo']);

            // 2nd form
            $different_user_date_of_birth = $user['date_of_birth'];
            $different_user_age = $user['age'];
            $different_user_use_phone_number = $user['use_phone_number'];
            $different_user_city = $user['city'];
            $different_user_province = $user['province'];
            $different_user_country = $user['country'];
            $different_user_user_URL = $user['user_URL'];

            // jobseeker form
            if($different_user_role == 'employee'){
                // $sex = $_SESSION['sex'] = $user['gender'] ?? null;
                $different_user_school = $user['school'];
                $different_user_degree = $user['degree'];
                $different_user_year_graduated = $user['year_graduated'];
                $different_user_job_title_experience = $user['job_title_experience'];
                $different_user_company_experience = $user['company_experience'];
                $different_user_year_of_service_experience = $user['year_of_service_experience'];
                $different_user_job_description_jobseeker = $user['job_description_jobseeker'];
                $different_user_jobseeker_skill = $user['jobseeker_skill'];
                $different_user_jobseeker_certification = $user['jobseeker_certification'];
                $different_user_porfolio = "data:image/jpeg;base64," . base64_encode($user['porfolio']);
                $different_user_job_type = $user['job_type'];
                $different_user_desired_industry = $user['desired_industry'];
                $different_user_expected_salary_range = $user['expected_salary_range'];
                $different_user_willingness_to_relocate = $user['willingness_to_relocate'];
                $different_user_work_schedule_preference = $user['work_schedule_preference'];
            }
            else if($different_user_role == 'employer'){
                $different_user_company_address_city = $user['company_address_city'];
                $different_user_company_address_province = $user['company_address_province'];
                $different_user_company_address_country = $user['company_address_country'];
                $different_user_company_address_URL = $user['company_address_URL'];
                $different_user_company_industry_type = $user['company_industry_type'];
                $different_user_company_size = $user['company_size'];
                $different_user_position_in_company = $user['position_in_company'];
                $different_user_years_with_company = $user['years_with_company'];
                $different_user_preferred_hiring_location = $user['preferred_hiring_location'];
                $different_user_salary_range = $user['salary_range'];
            }
        }
    } else {
        header('Location: opportUnity_login.php');
        exit();
    }
    // kapag employer nagvisit ng jobseeker eto gagana
}else if (isset($_POST['different_user_type']) && isset($_POST['different_user_userid']) && $_POST['different_user_type'] == "employer") 
{ 
    // ito ay para ihide yung edit button kapag nagview ng profile ng iba yung user
    $edit = false;

    // it ay para makita sa navigationbar yung profile ng user(hindi user na ivivisit)
    // Retrieve session variables
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $userID = $_SESSION['id'] ?? null;

    // Database connection
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';

    // Redirect to login page if not logged in
    if ($result && ($userNAME != null && $userPASSWORD != null)) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $first = $user['user_firstname'];
            $last = $user['user_lastname'];
            $name = $first . " " . $last;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);
        }
    }

    //eto naman yung para sa user na vivisit
    $different_user_type = $_POST['different_user_type']; 
    $different_user_userid = $_POST['different_user_userid'];

    // $different_user_userid at $different_user_role ay parehas lang

    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_ID='$different_user_userid' AND user_type='$different_user_type'";
    $result = mysqli_query($conn, $sql);

    $different_user_pic_identifier = '';
    
    if ($result) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $different_user_user = mysqli_fetch_assoc($result);
            $different_user_first = $user['user_firstname'];
            $different_user_last = $user['user_lastname'];
            $different_user_name = $different_user_first . " " . $different_user_last;
            $different_user_pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $different_user_role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $different_user_pic_identifier = base64_encode($user['profile_photo']);

            // 2nd form
            $different_user_date_of_birth = $user['date_of_birth'];
            $different_user_age = $user['age'];
            $different_user_use_phone_number = $user['use_phone_number'];
            $different_user_city = $user['city'];
            $different_user_province = $user['province'];
            $different_user_country = $user['country'];
            $different_user_user_URL = $user['user_URL'];

            // jobseeker form
            if($different_user_role == 'employee'){
                // $sex = $_SESSION['sex'] = $user['gender'] ?? null;
                $different_user_school = $user['school'];
                $different_user_degree = $user['degree'];
                $different_user_year_graduated = $user['year_graduated'];
                $different_user_job_title_experience = $user['job_title_experience'];
                $different_user_company_experience = $user['company_experience'];
                $different_user_year_of_service_experience = $user['year_of_service_experience'];
                $different_user_job_description_jobseeker = $user['job_description_jobseeker'];
                $different_user_jobseeker_skill = $user['jobseeker_skill'];
                $different_user_jobseeker_certification = $user['jobseeker_certification'];
                $different_user_porfolio = "data:image/jpeg;base64," . base64_encode($user['porfolio']);
                $different_user_job_type = $user['job_type'];
                $different_user_desired_industry = $user['desired_industry'];
                $different_user_expected_salary_range = $user['expected_salary_range'];
                $different_user_willingness_to_relocate = $user['willingness_to_relocate'];
                $different_user_work_schedule_preference = $user['work_schedule_preference'];
            }
            else if($different_user_role == 'employer'){
                $different_user_company_address_city = $user['company_address_city'];
                $different_user_company_address_province = $user['company_address_province'];
                $different_user_company_address_country = $user['company_address_country'];
                $different_user_company_address_URL = $user['company_address_URL'];
                $different_user_company_industry_type = $user['company_industry_type'];
                $different_user_company_size = $user['company_size'];
                $different_user_position_in_company = $user['position_in_company'];
                $different_user_years_with_company = $user['years_with_company'];
                $different_user_preferred_hiring_location = $user['preferred_hiring_location'];
                $different_user_salary_range = $user['salary_range'];
            }
        }
    } else {
        header('Location: opportUnity_login.php');
        exit();
    }
}
else{
    // ito ay para ipakita yung edit button kapag nagview ng profile yung sarili nya
    $edit = true;

    // Retrieve session variables
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $userID = $_SESSION['id'] ?? null;

    // Database connection
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';

    if ($result && ($userNAME != null && $userPASSWORD != null)) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $first = $user['user_firstname'];
            $last = $user['user_lastname'];
            $name = $first . " " . $last;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);
            $user_notification = $user['user_notification'];

            // 2nd form
            $date_of_birth = $user['date_of_birth'];
            $age = $user['age'];
            $use_phone_number = $user['use_phone_number'];
            $city = $user['city'];
            $province = $user['province'];
            $country = $user['country'];
            $user_URL = $user['user_URL'];

            // jobseeker form
            if($role == 'employee'){
                // $sex = $_SESSION['sex'] = $user['gender'] ?? null;
                $school = $user['school'];
                $degree = $user['degree'];
                $year_graduated = $user['year_graduated'];
                $job_title_experience = $user['job_title_experience'];
                $company_experience = $user['company_experience'];
                $year_of_service_experience = $user['year_of_service_experience'];
                $job_description_jobseeker = $user['job_description_jobseeker'];
                $jobseeker_skill = $user['jobseeker_skill'];
                $jobseeker_certification = $user['jobseeker_certification'];
                $porfolio = "data:image/jpeg;base64," . base64_encode($user['porfolio']);
                $job_type = $user['job_type'];
                $desired_industry = $user['desired_industry'];
                $expected_salary_range = $user['expected_salary_range'];
                $willingness_to_relocate = $user['willingness_to_relocate'];
                $work_schedule_preference = $user['work_schedule_preference'];
            }
            else if($role == 'employer'){
                $company_address_city = $user['company_address_city'];
                $company_address_province = $user['company_address_province'];
                $company_address_country = $user['company_address_country'];
                $company_address_URL = $user['company_address_URL'];
                $company_industry_type = $user['company_industry_type'];
                $company_size = $user['company_size'];
                $position_in_company = $user['position_in_company'];
                $years_with_company = $user['years_with_company'];
                $preferred_hiring_location = $user['preferred_hiring_location'];
                $salary_range = $user['salary_range'];
            }
        }
    } else {
        header('Location: opportUnity_login.php');
        exit();
    }
}
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM `admin` WHERE `user_ID` = '$userID'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);
    $AccountState = $user['AccountState'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="opportUnity_dashboard_jobseeker.css">
    <link rel="icon" type="image/png" href="faviconlogo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spectral&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
        <div class="navbar-left">
            <img onclick="logout()" src="logo.png" alt="OpportUnity Logo" class="navbar-logo">
            <div onclick="logout()" class="logo">OpportUnity</div>
            <ul class="nav-links">
                <li><a href="opportUnity.html">Landing Page</a></li>
                <li><a href="#">Terms & Condition</a></li>
            </ul>
        </div>
        <div class="navbar-right">
            <div id="userMenu" class="user-menu">
                <span id="userName">Welcome, <?=$name?>!</span>
                <div id="dropdown" class="dropdown-content">
                    <a href="profile.html">View Profile</a>
                    <a href="#" onclick="logout()">Logout</a>
                </div>
            </div>
            <a href="opportUnity_notification_list.php"><div id="user_notif" onclick="" style="width:40px; height:40px; border-radius:100%; background-size:cover; margin:0px 20px 0px 30px;"></div></a>
            <?php if(!($pic_identifier == null)){?>
                <a href="view_profile.php"><img style="border-radius:100%;" href="view_profile.php" src="<?=$pic?>" alt="" width="40px" height="40px"></a>
            <?php }else{?>
                <a href="view_profile.php"><img style="border-radius:100%;" href="view_profile.php" src="default_profile.jpg" alt="" width="40px" height="40px"></a>
            <?php }?>
        </div>
    </nav>

    <div>
        <div id="container">
            <div style="display:flex; justify-content:space-between;">
                <a href="opportUnity_dashboard_jobseeker.php"><button>
                <--
            </button></a>
            
        <span style="width:100px; height:30px; border-radius:20px; background-color:lime; display:flex; justify-content:center; align-items:center;"><?=$AccountState?></span>
            </div>
            
            <?php if ($edit) {?>
            <form action="opportUnity_edit_profile.php" method="POST">
                <input type="hidden" name="role" value="<?=$role?>">
                <input type="hidden" name="user_ID" value="<?=$user_ID?>">
                <button type="submit">edit profile</button>
            </form>
            <?php }?>
            <!-- kapag may value yung $different_user_role -->
            <?php if(!(isset($different_user_role))) 
                    {
                        if($role == 'employee'){
                ?>
                <!-- walang profile photo na ididisplay kasi meron nang pic sa upper right na nav bar -->
                <div style="display:flex;"><h4>school: </h4><?=$school?></div>
                <div style="display:flex;"><h4>degree: </h4><?=$degree?></div>
                <div style="display:flex;"><h4>year graduated: </h4><?=$year_graduated?></div>
                <div style="display:flex;"><h4>job title experience: </h4><?=$job_title_experience?></div>
                <div style="display:flex;"><h4>company experience: </h4><?=$company_experience?></div>
                <div style="display:flex;"><h4>year of service experience: </h4><?=$year_of_service_experience?></div>
                <div style="display:flex;"><h4>job description jobseeker: </h4><?=$job_description_jobseeker?></div>
                <div style="display:flex;"><h4>jobseeker skill: </h4><?=$jobseeker_skill?></div>
                <div style="display:flex;"><h4>jobseeker certification: </h4><?=$jobseeker_certification?></div>
                <div style="display:flex;"><h4>porfolio: </h4><img src="<?=$porfolio?>" alt=""></div>
                <div style="display:flex;"><h4>job type: </h4><?=$job_type?></div>
                <div style="display:flex;"><h4>desired industry: </h4><?=$desired_industry?></div>
                <div style="display:flex;"><h4>expected salary range: </h4><?=$expected_salary_range?></div>
                <div style="display:flex;"><h4>willingness to relocate: </h4><?=$willingness_to_relocate?></div>
                <div style="display:flex;"><h4>work schedule preference: </h4><?=$work_schedule_preference?></div>
            <?php }else if($role == 'employer'){?>
                <div style="display:flex;"><h4>company address city: </h4><?=$company_address_city?></div>
                <div style="display:flex;"><h4>company address province: </h4><?=$company_address_province?></div>
                <div style="display:flex;"><h4>company address country: </h4><?=$company_address_country?></div>
                <div style="display:flex;"><h4>company address URL: </h4><a href="<?=$company_address_URL?>"><?=$company_address_URL?></a></div>
                <div style="display:flex;"><h4>company industry type: </h4><?=$company_industry_type?></div>
                <div style="display:flex;"><h4>company size: </h4><?=$company_size?></div>
                <div style="display:flex;"><h4>position in company: </h4><?=$position_in_company?></div>
                <div style="display:flex;"><h4>years with company: </h4><?=$years_with_company?></div>
                <div style="display:flex;"><h4>preferred hiring_location: </h4><?=$preferred_hiring_location?></div>
                <div style="display:flex;"><h4>salary range: </h4><?=$salary_range?></div>
            <?php }
            }else{?>
            <!-- gagana lang tong else statement kapag viview ng user and profile ng ibang user -->
            <?php if($different_user_role == 'employee'){?>
                <div style="display:flex;"><h4>Profile Photo: </h4><img src="<?=$different_user_pic?>" alt="" width="100px" height="100px"></div>
                <div style="display:flex;"><h4>Full Name: </h4><?=$different_user_name?></div>
                <div style="display:flex;"><h4>school: </h4><?=$different_user_school?></div>
                <div style="display:flex;"><h4>degree: </h4><?=$different_user_degree?></div>
                <div style="display:flex;"><h4>year graduated: </h4><?=$different_user_year_graduated?></div>
                <div style="display:flex;"><h4>job title experience: </h4><?=$different_user_job_title_experience?></div>
                <div style="display:flex;"><h4>company experience: </h4><?=$different_user_company_experience?></div>
                <div style="display:flex;"><h4>year of service experience: </h4><?=$different_user_year_of_service_experience?></div>
                <div style="display:flex;"><h4>job description jobseeker: </h4><?=$different_user_job_description_jobseeker?></div>
                <div style="display:flex;"><h4>jobseeker skill: </h4><?=$different_user_jobseeker_skill?></div>
                <div style="display:flex;"><h4>jobseeker certification: </h4><?=$different_user_jobseeker_certification?></div>
                <div style="display:flex;"><h4>porfolio: </h4><img src="<?=$different_user_porfolio?>" alt=""></div>
                <div style="display:flex;"><h4>job type: </h4><?=$different_user_job_type?></div>
                <div style="display:flex;"><h4>desired industry: </h4><?=$different_user_desired_industry?></div>
                <div style="display:flex;"><h4>expected salary range: </h4><?=$different_user_expected_salary_range?></div>
                <div style="display:flex;"><h4>willingness to relocate: </h4><?=$different_user_willingness_to_relocate?></div>
                <div style="display:flex;"><h4>work schedule preference: </h4><?=$different_user_work_schedule_preference?></div>
            <?php }else if($different_user_role == 'employer'){?>
                <div style="display:flex;"><h4>Profile Photo: </h4><img src="<?=$different_user_pic?>" alt="" width="100px" height="100px"></div>
                <div style="display:flex;"><h4>Full Name: </h4><?=$different_user_name?></div>
                <div style="display:flex;"><h4>company address city: </h4><?=$different_user_company_address_city?></div>
                <div style="display:flex;"><h4>company address province: </h4><?=$different_user_company_address_province?></div>
                <div style="display:flex;"><h4>company address country: </h4><?=$different_user_company_address_country?></div>
                <div style="display:flex;"><h4>company address URL: </h4><a href="<?=$different_user_company_address_URL?>"><?=$different_user_company_address_URL?></a></div>
                <div style="display:flex;"><h4>company industry type: </h4><?=$different_user_company_industry_type?></div>
                <div style="display:flex;"><h4>company size: </h4><?=$different_user_company_size?></div>
                <div style="display:flex;"><h4>position in company: </h4><?=$different_user_position_in_company?></div>
                <div style="display:flex;"><h4>years with company: </h4><?=$different_user_years_with_company?></div>
                <div style="display:flex;"><h4>preferred hiring_location: </h4><?=$different_user_preferred_hiring_location?></div>
                <div style="display:flex;"><h4>salary range: </h4><?=$different_user_salary_range?></div>
            <?php }}?>
        </div>
    </div>
    <script>
        var user_notification = "<?=$user_notification?>";
    console.log(user_notification);
    var unotif = document.getElementById('user_notif');

    function user_notification_icon() {
        if (user_notification == 1) {
            unotif.style.backgroundImage = "url('red_notif.jpg')";
        } else {
            // Add your else condition here
            unotif.style.backgroundImage = "url('default_notif.jpg')"; // Example default image
        }
    }
// Call the function to set the initial icon 
    user_notification_icon();
    </script>
</body>
</html>