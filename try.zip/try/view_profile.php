<?php
// Start the session
session_start();

// ito ay kapag yung employer nagview ng profile ng user

// Retrieve session variables
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;

// Database connection
$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
$result = mysqli_query($conn, $sql);

$pic_identifier = '';

// Redirect to login page if not logged in
if ($result && ($userNAME != null && $userPASSWORD != null)) {
    $num_rows = mysqli_num_rows($result);
    if ($num_rows > 0) {
        $user = mysqli_fetch_assoc($result);
        $first = $user['user_firstname'];
        $last = $user['user_lastname'];
        $name = $first . " " . $last;
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
        $role = $user['user_type'];
        //para lang makita if may laman bang picture yung blob or wala
        $pic_identifier = base64_encode($user['profile_photo']);

        // 2nd form
        $date_of_birth = $user['date_of_birth'];
        $age = $user['age'];
        $use_phone_number = $user['use_phone_number'];
        $city = $user['city'];
        $province = $user['province'];
        $country = $user['country'];
        $user_URL = $user['user_URL'];

        // jobseeker form
        if($role == 'employee'){
            // $sex = $_SESSION['sex'] = $user['gender'] ?? null;
            $school = $user['school'];
            $degree = $user['degree'];
            $year_graduated = $user['year_graduated'];
            $job_title_experience = $user['job_title_experience'];
            $company_experience = $user['company_experience'];
            $year_of_service_experience = $user['year_of_service_experience'];
            $job_description_jobseeker = $user['job_description_jobseeker'];
            $jobseeker_skill = $user['jobseeker_skill'];
            $jobseeker_certification = $user['jobseeker_certification'];
            $porfolio = "data:image/jpeg;base64," . base64_encode($user['porfolio']);
            $job_type = $user['job_type'];
            $desired_industry = $user['desired_industry'];
            $expected_salary_range = $user['expected_salary_range'];
            $willingness_to_relocate = $user['willingness_to_relocate'];
            $work_schedule_preference = $user['work_schedule_preference'];
        }
        else if($role == 'employer'){
            $company_address_city = $user['company_address_city'];
            $company_address_province = $user['company_address_province'];
            $company_address_country = $user['company_address_country'];
            $company_address_URL = $user['company_address_URL'];
            $company_industry_type = $user['company_industry_type'];
            $company_size = $user['company_size'];
            $position_in_company = $user['position_in_company'];
            $years_with_company = $user['years_with_company'];
            $preferred_hiring_location = $user['preferred_hiring_location'];
            $salary_range = $user['salary_range'];
        }
    }
} else {
    header('Location: opportUnity_login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="opportUnity_dashboard_jobseeker.css">
    <link rel="icon" type="image/png" href="faviconlogo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spectral&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
        <div class="navbar-left">
            <img onclick="logout()" src="logo.png" alt="OpportUnity Logo" class="navbar-logo">
            <div onclick="logout()" class="logo">OpportUnity</div>
            <ul class="nav-links">
                <li><a href="opportUnity.html">Landing Page</a></li>
                <li><a href="#">Terms & Condition</a></li>
            </ul>
        </div>
        <div class="navbar-right">
            <div id="userMenu" class="user-menu">
                <span id="userName">Welcome, <?=$name?>!</span>
                <div id="dropdown" class="dropdown-content">
                    <a href="profile.html">View Profile</a>
                    <a href="#" onclick="logout()">Logout</a>
                </div>
            </div>
            <?php if(!($pic_identifier == null)){?>
                <a href="view_profile.php"><img style="border-radius:100%;" href="view_profile.php" src="<?=$pic?>" alt="" width="40px" height="40px"></a>
            <?php }else{?>
                <a href="view_profile.php"><img style="border-radius:100%;" href="view_profile.php" src="default_profile.jpg" alt="" width="40px" height="40px"></a>
            <?php }?>
        </div>
    </nav>

    <div>
        <div id="container">
            <?php if($role == 'employee'){?>
                <div style="display:flex;"><h4>school: </h4><?=$school?></div>
                <div style="display:flex;"><h4>degree: </h4><?=$degree?></div>
                <div style="display:flex;"><h4>year graduated: </h4><?=$year_graduated?></div>
                <div style="display:flex;"><h4>job title experience: </h4><?=$job_title_experience?></div>
                <div style="display:flex;"><h4>company experience: </h4><?=$company_experience?></div>
                <div style="display:flex;"><h4>year of service experience: </h4><?=$year_of_service_experience?></div>
                <div style="display:flex;"><h4>job description jobseeker: </h4><?=$job_description_jobseeker?></div>
                <div style="display:flex;"><h4>jobseeker skill: </h4><?=$jobseeker_skill?></div>
                <div style="display:flex;"><h4>jobseeker certification: </h4><?=$jobseeker_certification?></div>
                <div style="display:flex;"><h4>porfolio: </h4><img src="<?=$porfolio?>" alt=""></div>
                <div style="display:flex;"><h4>job type: </h4><?=$job_type?></div>
                <div style="display:flex;"><h4>desired industry: </h4><?=$desired_industry?></div>
                <div style="display:flex;"><h4>expected salary range: </h4><?=$expected_salary_range?></div>
                <div style="display:flex;"><h4>willingness to relocate: </h4><?=$willingness_to_relocate?></div>
                <div style="display:flex;"><h4>work schedule preference: </h4><?=$work_schedule_preference?></div>
            <?php }else if($role == 'employer'){?>
                <div style="display:flex;"><h4>company address city: </h4><?=$company_address_city?></div>
                <div style="display:flex;"><h4>company address province: </h4><?=$company_address_province?></div>
                <div style="display:flex;"><h4>company address country: </h4><?=$company_address_country?></div>
                <div style="display:flex;"><h4>company address URL: </h4><a href="<?=$company_address_URL?>"><?=$company_address_URL?></a></div>
                <div style="display:flex;"><h4>company industry type: </h4><?=$company_industry_type?></div>
                <div style="display:flex;"><h4>company size: </h4><?=$company_size?></div>
                <div style="display:flex;"><h4>position in company: </h4><?=$position_in_company?></div>
                <div style="display:flex;"><h4>years with company: </h4><?=$years_with_company?></div>
                <div style="display:flex;"><h4>preferred hiring_location: </h4><?=$preferred_hiring_location?></div>
                <div style="display:flex;"><h4>salary range: </h4><?=$salary_range?></div>
            <?php }?>
        </div>
    </div>
</body>
</html>