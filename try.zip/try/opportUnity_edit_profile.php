<?php

    // Global variables
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_username='$userNAME' AND user_password='$userPASSWORD'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';
    // purpose nito is kahit na ivisit ng user yung ibang user is mananatili padin yung notif nya
    if ($result && ($userNAME != null && $userPASSWORD != null)) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) 
        {
            $user = mysqli_fetch_assoc($result);
            $first = $user['user_firstname'];
            $last = $user['user_lastname'];
            $name = $first . " " . $last;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);
            $user_notification = $user['user_notification'];
            $user_ID = $user['user_ID'];
        }
    }


    $role = $_POST['role'];
    $user_ID = $_POST['user_ID'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "opportunity");
    $sql = "SELECT * FROM user WHERE user_ID='$user_ID' AND user_type='$role'";
    $result = mysqli_query($conn, $sql);

    $pic_identifier = '';

    // Redirect to login page if not logged in
    if ($result) {
        $num_rows = mysqli_num_rows($result);
        if ($num_rows > 0) {
            $user = mysqli_fetch_assoc($result);
            $user_firstname = $user['user_firstname'];
            $user_lastname = $user['user_lastname'];
            $user_username = $user['user_username'];
            $user_password = $user['user_password'];
            $name = $user_firstname . " " . $user_lastname;
            $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
            $role = $user['user_type'];
            //para lang makita if may laman bang picture yung blob or wala
            $pic_identifier = base64_encode($user['profile_photo']);

            // 2nd form
            $date_of_birth = $user['date_of_birth'];
            $age = $user['age'];
            $use_phone_number = $user['use_phone_number'];
            $city = $user['city'];
            $province = $user['province'];
            $country = $user['country'];
            $user_URL = $user['user_URL'];


            // jobseeker form
            if($role == 'employee'){
                // $sex = $_SESSION['sex'] = $user['gender'] ?? null;
                $school = $user['school'];
                $degree = $user['degree'];
                $year_graduated = $user['year_graduated'];
                $job_title_experience = $user['job_title_experience'];
                $company_experience = $user['company_experience'];
                $year_of_service_experience = $user['year_of_service_experience'];
                $job_description_jobseeker = $user['job_description_jobseeker'];
                $jobseeker_skill = $user['jobseeker_skill'];
                $jobseeker_certification = $user['jobseeker_certification'];
                $porfolio = "data:image/jpeg;base64," . base64_encode($user['porfolio']);
                $job_type = $user['job_type'];
                $desired_industry = $user['desired_industry'];
                $expected_salary_range = $user['expected_salary_range'];
                $willingness_to_relocate = $user['willingness_to_relocate'];
                $work_schedule_preference = $user['work_schedule_preference'];
            }
            else if($role == 'employer'){
                $company_address_city = $user['company_address_city'];
                $company_address_province = $user['company_address_province'];
                $company_address_country = $user['company_address_country'];
                $company_address_URL = $user['company_address_URL'];
                $company_industry_type = $user['company_industry_type'];
                $company_size = $user['company_size'];
                $position_in_company = $user['position_in_company'];
                $years_with_company = $user['years_with_company'];
                $preferred_hiring_location = $user['preferred_hiring_location'];
                $salary_range = $user['salary_range'];
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - OpportUnity</title>

    <link rel="stylesheet" href="opportUnity_signup.css">

    <link rel="icon" type="image/png" href="faviconlogo.png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spectral&display=swap" rel="stylesheet">
    
</head>
<body>
    <!-- Nav bar -->
    <nav class="navbar">
        <div class="navbar-left">
            <a href="opportUnity.html"><img src="logo.png" alt="OpportUnity Logo" class="navbar-logo"></a>
            <a href="opportUnity.html"><div class="logo">OpportUnity</div></a>
            <ul class="nav-links">
                <li><a href="opportUnity.html">Landing Page</a></li>
                <li><a href="#">Terms & Condition</a></li>
            </ul>
        </div>
    </nav>
            <?php
                session_start();
            if (isset($_SESSION['error'])) {
                echo '<script>alert("' . $_SESSION['error'] . '");</script>';
                unset($_SESSION['error']);
            }
            ?>

    <!-- Starting -->
    <div style="height:auto;">
        <div class="signup-container">
            <p>Grab Opportunity with us!</p>
            

            

            <!-- Form -->
            <form action="edit_profile.php" method="POST" enctype="multipart/form-data">

            
                <div class="name-fields">
                    <div class="input-group">
                        <input type="text" name="first_name" id="first_name" value="<?=$user_firstname?>" required>
                        <label for="first_name">First name</label>
                    </div>
                    <div class="input-group">
                        <input type="text" name="last_name" id="last_name" value="<?=$user_lastname?>" required>
                        <label for="last_name">Last name</label>
                    </div>
                </div>

                <div class="input-group">
                    <input type="email" name="email" id="email" value="<?=$user_username?>" required>
                    <label for="email">Email</label>
                </div>

                <div class="input-group">
                    <input type="password" name="password" id="password" value="<?=$user_password?>" required>
                    <label for="password">Password</label>
                </div>

                <div class="input-group">
                    <input type="password" name="confirm_password" id="confirm_password" value="<?=$user_password?>" required>
                    <label for="confirm_password">Confirm Password</label>
                </div>

                
                

                <input class="inputs" type="text" name="date_of_birth" value="<?=$date_of_birth?>">
                <input class="inputs" type="text" name="age" value="<?=$age?>">
                <input class="inputs" type="text" name="use_phone_number" value="<?=$use_phone_number?>">
                <input class="inputs" type="text" name="city" value="<?=$city?>">
                <input class="inputs" type="text" name="province" value="<?=$province?>">
                <input class="inputs" type="text" name="country" value="<?=$country?>">
                <input class="inputs" type="hidden" name="role" value="<?=$role?>">
                <input class="inputs" type="hidden" name="user_ID" value="<?=$user_ID?>">
                <!-- <input type="file" name="pic" value="<?=$pic?>"><br/> -->

                <?php if($role == "employee"){?>
                <!-- jobseeker -->
                <div id="jobseeker" class="secondfrm">
                    <!-- educational background -->
                    <input class="inputs" type="text" name="school" value="<?=$school?>" >
                    <input class="inputs" type="text" name="degree" value="<?=$degree?>" >
                    <input class="inputs" type="text" name="year_graduated" value="<?=$year_graduated?>">

                    <!-- work experience -->
                    <input class="inputs" type="text" name="job_title_experience" value="<?=$job_title_experience?>">
                    <input class="inputs" type="text" name="company_experience" value="<?=$company_experience?>">
                    <input class="inputs" type="text" name="year_of_service_experience" value="<?=$year_of_service_experience?>">
                    <input class="inputs" type="text" name="job_description_jobseeker" value="<?=$job_description_jobseeker?>"> 

                    <!-- skills and certification -->
                    <input class="inputs" type="text" name="jobseeker_skill" value="<?=$jobseeker_skill?>">
                    <input class="inputs" type="text" name="jobseeker_certification" value="<?=$jobseeker_certification?>">

                    <!-- portfolio/resume -->
                    <!-- <input type="file" name="porfolio"><br/> -->

                    <!-- profile url -->
                    <input class="inputs" type="text" name="user_URL" value="<?=$user_URL?>"> 

                    <!-- preference -->
                    <input class="inputs" type="text" name="job_type" value="<?=$job_type?>">
                    <input class="inputs" type="text" name="desired_industry" value="<?=$desired_industry?>">
                    <input class="inputs" type="text" name="expected_salary_range" value="<?=$expected_salary_range?>">
                    <input class="inputs" type="text" name="willingness_to_relocate" value="<?=$willingness_to_relocate?>"> 
                    <input class="inputs" type="text" name="work_schedule_preference" value="<?=$work_schedule_preference?>">
                </div>
                <?php }else if($role == "employer"){?>
                <!-- employer -->
                <div id="employer"  class="secondfrm">
                    <!-- Company Address -->
                    <input class="inputs" type="text" name="company_address_city" value="<?=$company_address_city?>" >
                    <input class="inputs" type="text" name="company_address_province" value="<?=$company_address_province?>" >
                    <input class="inputs" type="text" name="company_address_country" value="<?=$company_address_country?>" >
                    <input class="inputs" type="text" name="company_address_URL" value="<?=$company_address_URL?>" > 
                    <input class="inputs" type="text" name="company_industry_type" value="<?=$company_industry_type?>">
                    <input class="inputs" type="text" name="company_size" value="<?=$company_size?>" >

                    <!-- Professional Details -->
                    <input class="inputs" type="text" name="position_in_company" value="<?=$position_in_company?>">
                    <input class="inputs" type="text" name="years_with_company" value="<?=$years_with_company?>">
                    <input class="inputs" type="text" name="user_URL" value="<?=$user_URL?>"> 

                    <!-- Preference for Job Postings -->
                    <input class="inputs" type="text" name="preferred_hiring_location" value="<?=$preferred_hiring_location?>" >
                    <input class="inputs" type="text" name="salary_range" value="<?=$salary_range?>" >
                </div>
                <?php }?>
                <button type="submit" class="btn">Edit Account</button>
            </form>
            <!-- Finale -->
            <div class="terms">
                    <p>
                        By creating an account, you agree to our <br><a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a>.
                    </p>
                 </div>
        </div>
    </div>
</body>
</html>

