<form action="admin.php" id="login" method="POST">
        <input name="username" type="text" placeholder="username">
        <input name="password" type="password" placeholder="password">
        <input name="submit" type="submit" value="submit">
</form>