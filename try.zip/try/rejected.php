<?php
session_start();
$_SESSION['user_statusDistributerzz'] = "rejected";
$request = $_GET["user_id"];

$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT u.* FROM user u INNER JOIN application_logs al ON u.user_ID = al.jobseeker_userid WHERE al.jobid = '".$request."' AND al.user_status = 'Rejected' ORDER BY al.datetime_apply DESC;";
$result = mysqli_query($conn, $sql);

$job = array();

while($row = mysqli_fetch_assoc($result))
{
    $job[] = $row;
}

echo json_encode($job);
?>