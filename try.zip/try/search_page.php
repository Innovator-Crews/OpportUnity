<?php
// Start the session
session_start();

// Retrieve session variables
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;
$usertype = $_SESSION['usertype'] ?? null;

// Database connection
$conn = new mysqli("localhost", "root", "", "opportunity");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$pic = '';
$pic_identifier = '';
$firstname = '';
$lastname = '';

// If the main page cannot be accessed without logging in
// This is responsible for redirecting the user into the login page
if ($userNAME && $userPASSWORD && $usertype == "employee") {
    $sql = "SELECT * FROM user WHERE user_username=? AND user_password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $userNAME, $userPASSWORD);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
        $pic_identifier = base64_encode($user['profile_photo']);
        $user_notification = $user['user_notification'];
        $firstname = $user['user_firstname'];
        $lastname = $user['user_lastname'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="opportUnity_dashboard_jobseeker.php"><button><---</button></a><br>
    <input type="search" value="" onkeyup="search(this)">
    <div id="job-list-container"></div>
    <script>
var currentUrl = window.location.href;
        function search(find) {
            console.log(find.value);
            // AJAX
            var xml = new XMLHttpRequest();
            var method = "GET";
            var url = "search.php?jobSearch=" + find.value;
            var asynchronous = true;
            xml.open(method, url, asynchronous);
            xml.send();
            xml.onreadystatechange = function() {
                if (this.readyState == 4) {
                    if (this.status == 200) {
                        try {
                            var data = JSON.parse(this.responseText);
                            console.log(data);
                            console.log(data.length);
                            var htmldata = document.getElementById('job-list-container');
                            var html = '';
                            for (var i = 0; i < data.length; i++) {
                                // Retrieve the data using AJAX from SQL
                                var jobid = data[i].jobid;
                                var companyname = data[i].companyname;
                                var jobname = data[i].jobname;
                                var jobdesc = data[i].jobdesc;
                                var job_location = data[i].job_location;
                                var salary = data[i].salary;
                                var requirements = data[i].requirements;
                                var qualities = data[i].qualities;
                                var expectation = data[i].expectation;
                                var employer_userid = data[i].userid;
                                var datetime_job_created = data[i].datetime_job_created;
                                html += "<div class='cntx'><div class='cnpc'>";
                                html += "</div>";
                                html += "<h1 class='jobposition'> Job position: " + jobname + "</h1>";
                                html += "<h2> Salary $" + salary + "</h2>";
                                html += "<h3 class='cname'> Company: " + companyname + "</h3>";
                                html += "<h5> Job Description: " + jobdesc + "</h5>";
                                html += "<h5> Job Requirements: " + requirements + "</h5>";
                                html += "<h5> Job Qualities: " + qualities + "</h5>";
                                html += "<h5> Job Expectations: " + expectation + "</h5>";
                                html += "<h5 class='jid'> Job ID: " + jobid + "</h5>";
                                html += "<form action='apply.php' method='POST'>";
                                html += "<input type='hidden' name='jobpos' value='" + jobname + "'>";
                                html += "<input type='hidden' name='compName' value='" + companyname + "'>";
                                html += "<input type='hidden' name='fname' value='" + <?= json_encode($firstname) ?> + "'>";
                                html += "<input type='hidden' name='lname' value='" + <?= json_encode($lastname) ?> + "'>";
                                html += "<input type='hidden' name='job_id' value='" + jobid + "'>";
                                html += "<input type='hidden' name='user_id' value='" + employer_userid + "'>";
                                html += '<input type="hidden" name="currentUrl" value="' + currentUrl + '">';
                                html += "<button type='sumbit'>APPLY</button></form>";
                                html += "</div>";
                            }
                            htmldata.innerHTML = html;
                        } catch (e) {
                            console.error("Error parsing JSON:", e);
                        }
                    } else {
                        console.error("AJAX request failed with status:", this.status);
                    }
                }
            };
        }
    </script>
</body>
</html>
