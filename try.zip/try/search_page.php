<?php
// Start the session
session_start();

// Retrieve session variables
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;
$usertype = $_SESSION['usertype'] ?? null;

// Database connection
$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT * FROM user WHERE user_username=? AND user_password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userNAME, $userPASSWORD);
$stmt->execute();
$result = $stmt->get_result();

// Initialize $pic
$pic = '';
$pic_identifier = '';

// If the main page cannot be accessed without logging in
// This is responsible for redirecting the user into the login page
if ($result && ($userNAME != null && $userPASSWORD != null) && $usertype == "employee") {
    $num_rows = mysqli_num_rows($result);
    if ($num_rows > 0) {
        $user = mysqli_fetch_assoc($result);
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
        //para lang makita if may laman bang picture yung blob or wala
        $pic_identifier = base64_encode($user['profile_photo']);
        $user_notification = $user['user_notification'];
        
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <input type="search" value="" onkeyup="search(this)">
    <div id="job-list-container"></div>
    <script>
        function search(find) {
            console.log(find.value);
            // AJAX
            var xml = new XMLHttpRequest();
            var method = "GET";
            var url = "search.php?jobSearch=" + find.value;
            var asynchronous = true;

            xml.open(method, url, asynchronous);
            xml.send();
            xml.onreadystatechange = function() {
                if (this.readyState == 4) {
                    if (this.status == 200) {
                        try {
                            var data = JSON.parse(this.responseText);
                            console.log(data);
                            console.log(data.length);
                            var htmldata = document.getElementById('job-list-container');
                            var html = '';
                            for (var i = 0; i < data.length; i++) {
                                // Retrieve the data using AJAX from SQL
                                var jobid = data[i].jobid;
                                var companyname = data[i].companyname;
                                var jobname = data[i].jobname;
                                var jobdesc = data[i].jobdesc;
                                var job_location = data[i].job_location;
                                var salary = data[i].salary;
                                var requirements = data[i].requirements;
                                var qualities = data[i].qualities;
                                var expectation = data[i].expectation;
                                var userid = data[i].userid;
                                var datetime_job_created = data[i].datetime_job_created;

                                html += "<div class='cntx'><div class='cnpc'>";
                                html += "</div>";
                                html += "<h1 class='jobposition'> Job position: " + jobname + "</h1>";
                                html += "<h2> Salary $" + salary + "</h2>";
                                html += "<h3 class='cname'> Company: " + companyname + "</h3>";
                                html += "<h5> Job Description: " + jobdesc + "</h5>";
                                html += "<h5> Job Requirements: " + requirements + "</h5>";
                                html += "<h5> Job Qualities: " + qualities + "</h5>";
                                html += "<h5> Job Expectations: " + expectation + "</h5>";
                                html += "<h5 class='jid'> Job ID: " + jobid + "</h5>";
                                html += "<input type='hidden' class='employerid' value='" + userid + "'>";
                                html += "<button onclick='applyy(this)'>APPLY</button>";
                                html += "</div>";
                            }
                            htmldata.innerHTML = html;
                        } catch (e) {
                            console.error("Error parsing JSON:", e);
                        }
                    } else {
                        console.error("AJAX request failed with status:", this.status);
                    }
                }
            };
        }
    </script>
</body>
</html>
