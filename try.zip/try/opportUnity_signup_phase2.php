<?php
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $username = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
        .backbtn{
            height:10%;
            width: 90%;
            display:flex;
            align-items:center;
            font-weight: bold;
            color:black;
            font-size:25px;
        }
        form{
            height:auto;
            width: 100%;
            display:flex;
            flex-direction:column;
            justify-content:space-around;
            align-items:center;
        }
        .signupfrm{
            height:auto;
            width: 400px;
            backdrop-filter: blur(10px);
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            border-radius:10px;
            box-shadow:0px 0px 5px black;
        }
        .btnspc{
            height:90px;
            width: 300px;
            display:flex;
            justify-content:center;
            align-items:center;
        }
        body{
            height:auto;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            background:url("bgdes.jpg");
            background-size:cover;
        }
        a{
            text-decoration:none;
            color:black;
        }
        .gendiv{
            display:flex;
            justify-content:space-between;
            align-items:center;
            width: 60%;
        }
        .inputs{
            width: 250px;
            height: 40px;
            border-radius:5px;
            border:2px solid white;
        }
        .btn{
            width: 250px;
            height: 40px;
            border-radius:5px;
            background-color:Transparent;
            transition:0.5s;
            border:2px solid white;
        }
        .btn:hover{
            background-color:white;
        }
        #exp_option{
            display:none;
            flex-direction:column;
        }
        .secondfrm{
            display:none ;
            flex-direction:column;
            justify-content:space-evenly;
            height:100%;
        }
    </style>
</head>
<body>
<div class="signupfrm">
    <span class="backbtn">
        <a href="opportUnity.html">←</a>    
    </span>        
    <form action="signup.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="first_name" value="<?php echo $firstname; ?>">
        <input type="hidden" name="last_name" value="<?php echo $lastname; ?>">
        <input type="hidden" name="email" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
        <input type="hidden" name="role" value="<?php echo $role; ?>">

        <input class="inputs" type="text" name="date_of_birth" placeholder="Date of Birth:  ex:2000-12-30">
        <input class="inputs" type="text" name="age" placeholder="Age">
        <input class="inputs" type="text" name="use_phone_number" placeholder="09XXXXXXXXX">
        <input class="inputs" type="text" name="city" placeholder="city">
        <input class="inputs" type="text" name="province" placeholder="province">
        <input class="inputs" type="text" name="country" placeholder="country">
        <input type="file" name="pic"><br/>

        <!-- jobseeker -->
        <div id="jobseeker" class="secondfrm">
            <!-- educational background -->
            <input class="inputs" type="text" name="school" placeholder="School">
            <input class="inputs" type="text" name="degree" placeholder="Degree">
            <input class="inputs" type="text" name="year_graduated" placeholder="Year Graduated:  ex:2000-12-30">

            <!-- work experience -->
            <input class="inputs" type="text" name="job_title_experience" placeholder="Job Title">
            <input class="inputs" type="text" name="company_experience" placeholder="Degree">
            <input class="inputs" type="text" name="year_of_service_experience" placeholder="Years of Service:  ex:2">
            <input class="inputs" type="text" name="job_description_jobseeker" placeholder="Job Description"> 

            <!-- skills and certification -->
            <input class="inputs" type="text" name="jobseeker_skill" placeholder="Skills">
            <input class="inputs" type="text" name="jobseeker_certification" placeholder="Certification">

            <!-- portfolio/resume -->
            <input type="file" name="porfolio"><br/>

            <!-- profile url -->
            <input class="inputs" type="text" name="user_URL" placeholder="type the Link"> 

            <!-- preference -->
            <input class="inputs" type="text" name="job_type" placeholder="Job type">
            <input class="inputs" type="text" name="desired_industry" placeholder="Desired Industry">
            <input class="inputs" type="text" name="expected_salary_range" placeholder="Expected Salary Range">
            <input class="inputs" type="text" name="willingness_to_relocate" placeholder="Willingness to Relocate"> 
            <input class="inputs" type="text" name="work_schedule_preference" placeholder="Work Schedule Preference">
        </div>

        <!-- employer -->
        <div id="employer"  class="secondfrm">
            <!-- Company Address -->
            <input class="inputs" type="text" name="company_address_city" placeholder="city">
            <input class="inputs" type="text" name="company_address_province" placeholder="province">
            <input class="inputs" type="text" name="company_address_country" placeholder="country">
            <input class="inputs" type="text" name="company_address_URL" placeholder="type the Link"> 
            <input class="inputs" type="text" name="company_industry_type" placeholder="Desired Industry">
            <input class="inputs" type="text" name="company_size" placeholder="Company Size">

            <!-- Professional Details -->
            <input class="inputs" type="text" name="position_in_company" placeholder="Job Title">
            <input class="inputs" type="text" name="years_with_company" placeholder="Degree">
            <input class="inputs" type="text" name="user_URL" placeholder="type the Link"> 

            <!-- Preference for Job Postings -->
            <input class="inputs" type="text" name="preferred_hiring_location" placeholder="Preferred Hiring Location">
            <input class="inputs" type="text" name="salary_range" placeholder="Salary Range">
        </div>
        <input class="btn" type="submit" name="submit">
    </form>
</div>

<script>
    var experience_radiobutton = document.getElementById('exp'); 
    var exp_option = document.getElementById('exp_option'); 
    var frm = document.getElementsByClassName('signupfrm')[0]; 

    var jobseeker = document.getElementById('jobseeker'); 
    var employer = document.getElementById('employer'); 

    var usertype = '<?=$role?>';

    if(usertype == "employee") jobseeker.style.display = "flex";
    else if(usertype == "employer") employer.style.display = "flex";

    // Add event listener to handle changes in the checkbox state
    experience_radiobutton.addEventListener('change', function() {
        if (experience_radiobutton.checked) {
            exp_option.style.display = "flex";
            frm.style.height = "800px";
        } else {
            exp_option.style.display = "none";
            frm.style.height = "500px";
        }
    });
</script>

</body>
</html>
