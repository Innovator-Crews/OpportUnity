<?php
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $username = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
        .backbtn{
            height:10%;
            width: 90%;
            display:flex;
            align-items:center;
            font-weight: bold;
            color:black;
            font-size:25px;
        }
        form{
            height:90%;
            width: 100%;
            display:flex;
            flex-direction:column;
            justify-content:space-around;
            align-items:center;
        }
        .signupfrm{
            height:500px;
            width: 400px;
            backdrop-filter: blur(10px);
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            border-radius:10px;
            box-shadow:0px 0px 5px black;
        }
        .btnspc{
            height:90px;
            width: 300px;
            display:flex;
            justify-content:center;
            align-items:center;
        }
        body{
            height:100vh;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            background:url("bgdes.jpg");
            background-size:cover;
        }
        a{
            text-decoration:none;
            color:black;
        }
        .gendiv{
            display:flex;
            justify-content:space-between;
            align-items:center;
            width: 60%;
        }
        .inputs{
            width: 250px;
            height: 40px;
            border-radius:5px;
            border:2px solid white;
        }
        .btn{
            width: 250px;
            height: 40px;
            border-radius:5px;
            background-color:Transparent;
            transition:0.5s;
            border:2px solid white;
        }
        .btn:hover{
            background-color:white;
        }
        #exp_option{
            display:none;
            flex-direction:column;
        }
    </style>
</head>
<body>
<div class="signupfrm">
    <span class="backbtn">
        <a href="opportUnity.html">←</a>    
    </span>        
    <form action="signup.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="first_name" value="<?php echo $firstname; ?>">
        <input type="hidden" name="last_name" value="<?php echo $lastname; ?>">
        <input type="hidden" name="email" value="<?php echo $username; ?>">
        <input type="hidden" name="password" value="<?php echo $password; ?>">
        <input type="hidden" name="role" value="<?php echo $role; ?>">

        <input type="file" name="pic"><br/>

        <div class="gendiv">
            <div class="gender">
                <input type="radio" id="m" name="gender" value="Male">
                <label for="m">Male</label>
            </div>
            <div class="gender">
                <input type="radio" id="f" name="gender" value="Female">
                <label for="f">Female</label>
            </div>
        </div>
        <div>
            <input type="checkbox" id="exp" name="exp" value="have_experience">
            <!-- pang may experience lang to -->
            <label for="exp">I have Experience</label>
        </div>
        <div id="exp_option" style="display: none;">
            <input class="inputs" type="text" name="experience_job_title" placeholder="Job Title">
            <input class="inputs" type="text" name="experience_job_company" placeholder="Job Company">
            <input class="inputs" type="text" name="experience_job_started" placeholder="Started:  ex:2024-11-15">
            <input class="inputs" type="text" name="experience_job_ended" placeholder="Ended:  ex:2024-11-15">
        </div>
        <input class="inputs" type="text" name="home_location" placeholder="Home Location: ">
        <input class="inputs" type="text" name="preferred_classification" placeholder="Preferred Classification: ">
        <input class="inputs" type="text" name="sub_classification" placeholder="Sub-Classification: ">
        <input class="btn" type="submit" name="submit">
    </form>
</div>

<script>
    var experience_radiobutton = document.getElementById('exp'); 
    var exp_option = document.getElementById('exp_option'); 
    var frm = document.getElementsByClassName('signupfrm')[0]; 

    // Add event listener to handle changes in the checkbox state
    experience_radiobutton.addEventListener('change', function() {
        if (experience_radiobutton.checked) {
            exp_option.style.display = "flex";
            frm.style.height = "800px";
        } else {
            exp_option.style.display = "none";
            frm.style.height = "500px";
        }
    });
</script>

</body>
</html>
