<?php
// Start the session
session_start();
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;
$role = $_SESSION['usertype'] ?? null;
require 'connection.php';


if(isset($_POST['currentUrl'])) $_SESSION['currentUrl'] = $_POST['currentUrl'];
if(isset($_POST['id'])) $_SESSION['jobId'] = $_POST['id']; 
if(isset($_POST['compname'])) $_SESSION['companyName'] = $_POST['compname'];
$currentUrl = $_SESSION['currentUrl'];


if (isset($_SESSION['message'])) 
{ 
    echo "<script>alert('" . $_SESSION['message'] . "');</script>"; 
    // Unset the session variable to prevent the alert from showing again 
    unset($_SESSION['message']); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            margin: 0px;
            padding: 0px;
        }
        .container {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }
        .control_buttons {
            width: 100%;
            height: 100px;
            background-color: #404040;
            display: flex;
            justify-content: space-evenly;
            align-items: center;
        }
        .hdr {
            margin: 5px 0px 0px 20px;
            color: white;
        }
        .header {
            width: 100%;
            height: 200px;
            background-color: #404040;
        }
        .list_applicants {
            width: 100%;
            height: 100%;
            box-shadow: 0px 0px 5px black inset;
            border-radius: 5px;
            background-color: #303030;
            display: flex;
            justify-content: space-evenly;
            align-items: start;
            overflow-y: scroll;
        }
        .btn {
            width: 170px;
            height: 50px;
            border-radius: 5px;
            color: white;
            background-color: transparent;
            border: 2px solid white;
            transition: 0.5s;
        }
        #list_area {
            width: 90%;
        }
        .cntx {
            width: 100%;
            height: 150px;
            border-radius: 5px;
            color: white;
            background-color: #202020;
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
    <div id="form_for_reason" style="height:100%; width:100%; background-color:black; position:absolute; display:none; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    <div style="height:100%; width:100%; display:flex; flex-direction:column; align-items:center;">
        <button style="height:60px; width:60px;" onclick="form_exit()">←</button>
        <div id="reasonform">

        </div>
    </div>
</div>


        <div class="header">
            <a href="<?=$currentUrl?>"><div class="hdr"><h1><?php echo $_SESSION['companyName']; ?></h1></div></a>
            <div class="control_buttons">
                <button id="waiting_list" onclick="idToString(this)" class="btn">Waiting List</button>
                <button id="short_listed" onclick="idToString(this)" class="btn">Short Listed</button>
                <button id="rejected" onclick="idToString(this)" class="btn">Rejected</button>
                <button id="accepted" onclick="idToString(this)" class="btn">Accepted</button>
            </div>
        </div>
        <div class="list_applicants">
            <div id="list_area"></div>
        </div>
    </div>

    <script>
        var jid = <?php echo $_SESSION['jobId']; ?>;
        var sd = "<?php echo $_SESSION['user_statusDistributerzz']; ?>";
        // pang form to kapag saasabihin ng employer reason
        var rejectedfrm = '';
        var short_listedfrm = '';

        var list = ["waiting_list", "short_listed", "rejected", "accepted"]; 
        var intervalId = setInterval(function() { getListOfJob(sd); }, 1000);

        console.log(sd);
        function idToString(s) {
            clearInterval(intervalId);
            getListOfJob(s.id);
            intervalId = setInterval(function() { getListOfJob(s.id); }, 1000);
        }

            

        function getListOfJob(s) {
            // AJAX
            var site = s;
            for (var i = 0; i < list.length; i++) { 
                if(list[i] != site) {
                    document.getElementById(list[i]).style.backgroundColor = "transparent";
                    document.getElementById(list[i]).style.color = "white";
                } else {
                    document.getElementById(list[i]).style.backgroundColor = "white";
                    document.getElementById(list[i]).style.color = "black";
                }
            }

            var xml = new XMLHttpRequest();
            var method = "GET";
            var url = site + ".php?user_id=" + jid;
            var asynchronous = true;

            xml.open(method, url, asynchronous);
            xml.send();
            xml.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var data = JSON.parse(this.responseText);
                    var htmldata = document.getElementById('list_area');
                    var html = '';
                    for (var i = 0; i < data.length; i++) {
                        // Retrieve the data using AJAX from SQL
                        let user_ID = data[i].user_ID;
                        let user_firstname = data[i].user_firstname;
                        let user_lastname = data[i].user_lastname;
                        let jobdesc = data[i].jobdesc;
                        let datetime_user_created = data[i].datetime_user_created;

                        html += "<div class='cntx'><div class='cnpc'>";
                        html += "</div>";
                        html += "<h3 class='cname'> Name: " + user_firstname + " " + user_lastname + "</h3>";
                        html += "<h5> Time: " + datetime_user_created + "</h5>";
                        html += "<h5> User ID: " + user_ID + "</h5>";
                        html += "<input type='hidden' class='jobseekerid' value='" + user_ID + "'>";

                        // View details Button Form
                        html += '<div style="display:flex; justify-content:space-evenly; width:50%;">';
                        if(site!="waiting_list"){
                            html += '<form id="btn_waitingList" action="status_changer.php" method="POST">';
                            // gagamitin ko lng to sa paglalagay sa application logs ng data
                            html += '<input type="hidden" name="user_id" value="' + user_ID + '">';
                            html += '<input type="hidden" name="job_id" value="' + jid + '">';
                            // eto naman pang transaction logs(mala notif na)
                            html += '<input type="hidden" name="status" value="Waiting List">';
                            html += '<button class="btn" type="submit">Waiting List</button></form>';
                        }
                        
                        if(site!="short_listed"){
                            short_listedfrm = '<form style="display:flex; flex-direction:column; justify-content:center; align-items:center;" action="status_changer.php" method="POST">';
                            short_listedfrm += '<input type="hidden" name="user_id" id="user_id" >';
                            short_listedfrm += '<input type="hidden" name="job_id" value="' + jid + '">';
                            short_listedfrm += '<textarea id="expectations" style="height:600px; width:900px;" name="message" rows="3" required></textarea>';
                            short_listedfrm += '<input type="hidden" name="status" value="Short Listed">';
                            short_listedfrm += '<button class="btn" type="submit">Short Listed</button>';
                            html += '<button onclick="gotShort_listedfrm(this)" class="btn" type="submit">Short Listed</button></form>';
                        }

                        // Edit Button Form
                        if(site!="rejected"){
                            rejectedfrm = '<form style="display:flex; flex-direction:column; justify-content:center; align-items:center;" action="status_changer.php" method="POST">';
                            rejectedfrm += '<input type="hidden" name="user_id" id="user_id" >';
                            rejectedfrm += '<input type="hidden" name="job_id" id="job_id"  value="' + jid + '">';
                            rejectedfrm += '<textarea id="expectations" style="height:600px; width:900px;" name="message" rows="3" required></textarea>';
                            rejectedfrm += '<input type="hidden" name="status" value="Rejected">';
                            rejectedfrm += '<button class="btn" type="submit">Rejected</button></form>';
                            html += '<button onclick="gotRejected(this)" class="btn" type="submit">Rejected</button>';
                        }

                        var msg = 'Are you sure you want to accept this job?';
                        // Delete Button Form
                        if(site!="accepted"){
                            html += '<form id="btn_accept" action="status_changer.php" method="POST" onsubmit="return confirm(\'' + msg + '\')">';
                            html += '<input type="hidden" name="user_id" value="' + user_ID + '">';
                            html += '<input type="hidden" name="job_id" value="' + jid + '">';
                            html += '<input type="hidden" name="status" value="Accepted">';
                            html += '<button class="btn" type="submit">Accepted</button></form>';
                        }
                        
                        html += "</div></div>";
                        
                    }
                    html += "</div>";
                    htmldata.innerHTML = html;
                }
            }

        }
        function gotRejected(button){
            var form_for_reason = document.getElementById('form_for_reason');
            document.getElementById('reasonform').innerHTML = rejectedfrm;
            form_for_reason.style.display = "block";
            var datatype_userid = button.closest('.cntx').querySelector('.jobseekerid').value;
            document.getElementById("user_id").value = datatype_userid;
        }
        function gotShort_listedfrm(button){
            var form_for_reason = document.getElementById('form_for_reason');
            document.getElementById('reasonform').innerHTML = short_listedfrm;
            form_for_reason.style.display = "block";
            var datatype_userid = button.closest('.cntx').querySelector('.jobseekerid').value;
            document.getElementById("user_id").value = datatype_userid;
        }
        function form_exit(){
            var form_for_reason = document.getElementById('form_for_reason');
            form_for_reason.style.display = "none";
        }
    </script>
</body>
</html>
