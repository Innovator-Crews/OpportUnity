<?php
    // Start the session
    session_start();
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $userID = $_SESSION['id'] ?? null;
    $role = $_SESSION['usertype'] ?? null;
    require 'connection.php';
    $jobId = $_POST['job_id'];
    $userStatus = $_POST['status'];
    $userID = $_POST['user_id'];

    $conn = new mysqli("localhost", "root", "", "opportunity");
    if($userStatus == "Short Listed") $sql = "UPDATE application_logs SET user_status = 'Short Listed' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
    else if($userStatus == "Rejected") $sql = "UPDATE application_logs SET user_status = 'Rejected' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
    else if($userStatus == "Accepted") $sql = "UPDATE application_logs SET user_status = 'Accepted' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";

    $result = mysqli_query($conn, $sql);
    header('Location: view_job.php');
    exit();
?>