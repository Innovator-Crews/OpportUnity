<?php
    // Start the session
    //dito nichachange if waitinglist, short list, rejected, or accepted yung nasa application_logs
    // dito din nichachange if hiring or full na yung job
    session_start();
    $userNAME = $_SESSION['username'] ?? null;
    $userPASSWORD = $_SESSION['password'] ?? null;
    $userID = $_SESSION['id'] ?? null;
    $role = $_SESSION['usertype'] ?? null;
    require 'connection.php';
    $jobId = $_POST['job_id'];
    $userStatus = $_POST['status'];
    $userID = $_POST['user_id'];

    //checking how many applicants is already accepted
    $sql = "SELECT COUNT(*) AS accepted_count FROM application_logs WHERE user_status = 'Accepted';";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result); 
    $number_of_accepted = $data['accepted_count'];
    

    //checking the number of limit in job
    $sql = "SELECT job_limit FROM job WHERE jobid = '".$jobId."';";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result); 
    $limit_job_number = $data['job_limit'];



    $conn = new mysqli("localhost", "root", "", "opportunity");
    if($userStatus == "Short Listed") {
        $sql = "UPDATE application_logs SET user_status = 'Short Listed' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
        $result = mysqli_query($conn, $sql);


        //checking how many applicants is already accepted
        $sql = "SELECT COUNT(*) AS accepted_count FROM application_logs WHERE user_status = 'Accepted';";
        $result = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($result); 
        $number_of_accepted = $data['accepted_count'];

        if($number_of_accepted<$limit_job_number){
            $sql = "UPDATE job SET job_status = 'Hiring' WHERE jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);
        }
        
    }
    else if($userStatus == "Rejected") {
        $sql = "UPDATE application_logs SET user_status = 'Rejected' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
        $result = mysqli_query($conn, $sql);


        $sql = "SELECT COUNT(*) AS accepted_count FROM application_logs WHERE user_status = 'Accepted';";
        $result = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($result); 
        $number_of_accepted = $data['accepted_count'];

        if($number_of_accepted<$limit_job_number){
            $sql = "UPDATE job SET job_status = 'Hiring' WHERE jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);
        }
        
    }    
    else if($userStatus == "Waiting List") {
        $sql = "UPDATE application_logs SET user_status = 'Waiting List' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
        $result = mysqli_query($conn, $sql);


        $sql = "SELECT COUNT(*) AS accepted_count FROM application_logs WHERE user_status = 'Accepted';";
        $result = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($result); 
        $number_of_accepted = $data['accepted_count'];

        if($number_of_accepted<$limit_job_number){
            $sql = "UPDATE job SET job_status = 'Hiring' WHERE jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);
        }
        
    }
    else{
        
        if($number_of_accepted<$limit_job_number-1){
            if($userStatus == "Accepted") $sql = "UPDATE application_logs SET user_status = 'Accepted' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);

            $sql = "UPDATE job SET job_status = 'Hiring' WHERE jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);
        }

        else if($number_of_accepted==$limit_job_number-1){
            if($userStatus == "Accepted") $sql = "UPDATE application_logs SET user_status = 'Accepted' WHERE jobseeker_userid = '".$userID."' AND jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);

            $sql = "UPDATE job SET job_status = 'Full' WHERE jobid = '".$jobId."';";
            $result = mysqli_query($conn, $sql);
        }

        else{
            $_SESSION['message'] = 'Job capacity is full';
            header('Location: view_job.php');
            exit();
        }
    }
    
    



    // $result = mysqli_query($conn, $sql);
    header('Location: view_job.php');
    exit();
?>