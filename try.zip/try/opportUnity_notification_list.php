<?php
// Start the session
session_start();

// Global variables
$userNAME = $_SESSION['username'] ?? null;
$userPASSWORD = $_SESSION['password'] ?? null;
$userID = $_SESSION['id'] ?? null;
$usertype = $_SESSION['usertype'] ?? null;


$conn = new mysqli("localhost", "root", "", "opportunity");

$sql = "UPDATE user SET user_notification = 0 WHERE user_ID = ?"; 
$stmt = $conn->prepare($sql); 
$stmt->bind_param("i", $userID); 
$stmt->execute();

$sql = "SELECT * FROM user WHERE user_username=? AND user_password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userNAME, $userPASSWORD);
$stmt->execute();
$result = $stmt->get_result();

// Initialize $pic
$pic = '';
$pic_identifier = '';

// If the main page cannot be accessed without logging in
// This is responsible for redirecting the user into the login page
if ($result && ($userNAME != null && $userPASSWORD != null)) {
    $num_rows = mysqli_num_rows($result);
    if ($num_rows > 0) {
        $user = mysqli_fetch_assoc($result);
        $pic = "data:image/jpeg;base64," . base64_encode($user['profile_photo']);
        //para lang makita if may laman bang picture yung blob or wala
        $pic_identifier = base64_encode($user['profile_photo']);
        $user_notification = $user['user_notification'];
    }

} else {
    session_abort();
    include 'opportUnity_login.php';
    exit();
}

$conn = new mysqli("localhost", "root", "", "opportunity");
$sql = "SELECT * FROM application_logs";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$htmlContent = '';

if ($result->num_rows > 0) {
    $first = $user['user_firstname'];
    $last = $user['user_lastname'];
    $name = $first . " " . $last;
    while ($user = $result->fetch_assoc()) {
        $jobid = $user['jobid'];
        $employer_userid = $user['employer_userid'];
        $job_position = $user['job_position'];
        $company_name = $user['company_name'];
        $first_name = $user['first_name'];
        $last_name = $user['last_name'];
        $jobsdec = $user['jobsdec'];
        $jobseeker_userid = $user['jobseeker_userid'];
        $datetime_apply = $user['datetime_apply'];
        $user_status = $user['user_status'];

        // Append the values to the HTML content
        $htmlContent .= "<div class='user-info'>";
        $htmlContent .= "<p>Job ID: $jobid</p>";
        $htmlContent .= "<p>Employer User ID: $employer_userid</p>";
        $htmlContent .= "<p>Job Position: $job_position</p>";
        $htmlContent .= "<p>Company Name: $company_name</p>";
        $htmlContent .= "<p>First Name: $first_name</p>";
        $htmlContent .= "<p>Last Name: $last_name</p>";
        $htmlContent .= "<p>Job Description: $jobsdec</p>";
        $htmlContent .= "<p>Jobseeker User ID: $jobseeker_userid</p>";
        $htmlContent .= "<p>Datetime Apply: $datetime_apply</p>";
        $htmlContent .= "<p>User Status: $user_status</p>";
        $htmlContent .= "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="opportUnity_dashboard_jobseeker.css">
    <link rel="icon" type="image/png" href="faviconlogo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spectral&display=swap" rel="stylesheet">
    <style>
        .user-info {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
<!-- Nav bar -->
    <nav class="navbar">
        <div class="navbar-left">
            <img onclick="logout()" src="logo.png" alt="OpportUnity Logo" class="navbar-logo">
            <div onclick="logout()" class="logo">OpportUnity</div>
            <ul class="nav-links">
                <li><a href="opportUnity.html">Landing Page</a></li>
                <li><a href="#">Terms & Condition</a></li>
            </ul>
        </div>
        <div class="navbar-right">
            <div id="userMenu" class="user-menu">
                <span id="userName">Welcome, <?=$name?>!</span>
                <div id="dropdown" class="dropdown-content">
                    <a href="profile.html">View Profile</a>
                    <a href="#" onclick="logout()">Logout</a>
                </div>
            </div>
            <a href="opportUnity_notification_list.php"><div id="user_notif" onclick="" style="width:40px; height:40px; border-radius:100%; background-size:cover; margin:0px 20px 0px 30px;"></div></a>
            <?php if(!($pic_identifier == null)){?>
                <a href="view_profile.php"><img href="view_profile.php" src="<?=$pic?>" alt="" style="width:40px; height:40px; border-radius:100%;"></a>
            <?php }else{?>
                <a href="view_profile.php"><img href="view_profile.php" src="default_profile.jpg" alt="" style="width:40px; height:40px; border-radius:100%;"></a>
            <?php }?>
            
        </div>
    </nav>
    <div id="container">
        <?php echo $htmlContent; ?>
    </div>
    <script>
        var user_notification = "<?=$user_notification?>";
        console.log(user_notification);
        var unotif = document.getElementById('user_notif');

        function user_notification_icon() {
            if (user_notification == 1) {
                unotif.style.backgroundImage = "url('red_notif.jpg')";
            } else {
                // Add your else condition here
                unotif.style.backgroundImage = "url('default_notif.jpg')"; // Example default image
            }
        }
        // Call the function to set the initial icon 
        user_notification_icon();
    </script>
</body>
</html>
